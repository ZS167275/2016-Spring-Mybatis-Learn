package mapodoufu.web.service;

import mapodoufu.web.enity.User;

import java.util.List;

/**
 * Created by ZhangShan on 2017/4/17.
 */
public interface UserService {

    List<User> getUserList() ;
}
