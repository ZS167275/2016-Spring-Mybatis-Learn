package mapodoufu.web.controller;

import mapodoufu.web.enity.User;
import mapodoufu.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.PublicKey;
import java.util.List;

/**
 * Created by ZhangShan on 2017/4/17.
 */
@Controller
public class UserController {

    @Autowired
    UserService userService;

    @RequestMapping("/listData")
    public String ListData(Model model){
        List<User> userList = userService.getUserList();
        System.out.println(userList);
        model.addAttribute("userList",userList);
        return "index";
    }
}
