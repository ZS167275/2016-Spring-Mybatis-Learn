package mapodoufu.web.mapper;

import mapodoufu.web.enity.User;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by ZhangShan on 2017/4/17.
 */
@Repository
public interface UserMapper {

    @Select("SELECT * FROM user")
    List<User> getUserList() ;

}
